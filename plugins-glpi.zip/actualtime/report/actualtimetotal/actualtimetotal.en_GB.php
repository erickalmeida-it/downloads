<?php
$LANG['plugin_actualtime']['actualtimetotal'] = "ActualTime Total";