<?php
$LANG['plugin_actualtime']['actualtimeuser'] = "ActualTime Users";