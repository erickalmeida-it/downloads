<?php
define("GLPI_ROOT", "../../..");
include GLPI_ROOT . "/inc/based_config.php";
echo "GLPI_LOG_DIR=" . GLPI_LOG_DIR . "\n";
echo "GLPI_LOCK_DIR=" . GLPI_LOCK_DIR . "\n";
